#
# SQL Export
# Created by Querious (998)
# Created: 25 de septiembre de 2015, 9:11:28 GMT-3
# Encoding: Unicode (UTF-8)
#


DROP TABLE IF EXISTS `region`;
DROP TABLE IF EXISTS `provincia`;
DROP TABLE IF EXISTS `pais`;
DROP TABLE IF EXISTS `comuna`;


CREATE TABLE `comuna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `id_provincia` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;


CREATE TABLE `pais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;


CREATE TABLE `provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `capital_provincial` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `id_region` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;


CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `numero` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `capital_regional` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `id_pais` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;




SET @PREVIOUS_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS;
SET FOREIGN_KEY_CHECKS = 0;


LOCK TABLES `comuna` WRITE;
ALTER TABLE `comuna` DISABLE KEYS;
ALTER TABLE `comuna` ENABLE KEYS;
UNLOCK TABLES;


LOCK TABLES `pais` WRITE;
ALTER TABLE `pais` DISABLE KEYS;
INSERT INTO `pais` (`id`, `nombre`) VALUES 
	(1,'Chile');
ALTER TABLE `pais` ENABLE KEYS;
UNLOCK TABLES;


LOCK TABLES `provincia` WRITE;
ALTER TABLE `provincia` DISABLE KEYS;
ALTER TABLE `provincia` ENABLE KEYS;
UNLOCK TABLES;


LOCK TABLES `region` WRITE;
ALTER TABLE `region` DISABLE KEYS;
ALTER TABLE `region` ENABLE KEYS;
UNLOCK TABLES;




SET FOREIGN_KEY_CHECKS = @PREVIOUS_FOREIGN_KEY_CHECKS;


