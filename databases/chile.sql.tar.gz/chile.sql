-- MySQL dump 10.13  Distrib 5.6.21, for osx10.8 (x86_64)
--
-- Host: localhost    Database: divison_geopolitica
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comuna`
--

DROP TABLE IF EXISTS `comuna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comuna` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `id_provincia` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comuna`
--

LOCK TABLES `comuna` WRITE;
/*!40000 ALTER TABLE `comuna` DISABLE KEYS */;
INSERT INTO `comuna` VALUES (1,'Arica',1),(2,'Camarones',1),(3,'General Lagos',2),(4,'Putre',2),(5,'Alto Hospicio',3),(6,'Iquique',3),(7,'Camiña',4),(8,'Colchane',4),(9,'Huara',4),(10,'Pica',4),(11,'Pozo Almonte',4),(12,'Antofagasta',5),(13,'Mejillones',5),(14,'Sierra Gorda',5),(15,'Taltal',5),(16,'Calama',6),(17,'Ollague',6),(18,'San Pedro de Atacama',6),(19,'María Elena',7),(20,'Tocopilla',7),(21,'Chañaral',8),(22,'Diego de Almagro',8),(23,'Caldera',9),(24,'Copiapó',9),(25,'Tierra Amarilla',9),(26,'Alto del Carmen',10),(27,'Freirina',10),(28,'Huasco',10),(29,'Vallenar',10),(30,'Canela',11),(31,'Illapel',11),(32,'Los Vilos',11),(33,'Salamanca',11),(34,'Andacollo',12),(35,'Coquimbo',12),(36,'La Higuera',12),(37,'La Serena',12),(38,'Paihuano',12),(39,'Vicuña',12),(40,'Combarbalá',13),(41,'Monte Patria',13),(42,'Ovalle',13),(43,'Punitaqui',13),(44,'Río Hurtado',13),(45,'Isla de Pascua',14),(46,'Calle Larga',15),(47,'Los Andes',15),(48,'Rinconada de Los Andes',15),(49,'San Esteban',15),(50,'Limache',16),(51,'Olmué',16),(52,'Quilpué',16),(53,'Villa Alemana',16),(54,'Cabildo',17),(55,'La Ligua',17),(56,'Papudo',17),(57,'Petorca',17),(58,'Zapallar',17),(59,'Hijuelas',18),(60,'La Calera',18),(61,'La Cruz',18),(62,'Nogales',18),(63,'Quillota',18),(64,'Algarrobo',19),(65,'Cartagena',19),(66,'El Quisco',19),(67,'El Tabo',19),(68,'San Antonio',19),(69,'Santo Domingo',19),(70,'Catemu',20),(71,'Llaillay',20),(72,'Panquehue',20),(73,'Putaendo',20),(74,'San Felipe',20),(75,'Santa María',20),(76,'Casablanca',21),(77,'Concón',21),(78,'Juan Fernández',21),(79,'Puchuncaví',21),(80,'Quintero',21),(81,'Valparaíso',21),(82,'Viña del Mar',21),(83,'Codegua',22),(84,'Coínco',22),(85,'Coltauco',22),(86,'Doñihue',22),(87,'Graneros',22),(88,'Las Cabras',22),(89,'Machalí',22),(90,'Malloa',22),(91,'Olivar',22),(92,'Peumo',22),(93,'Pichidegua',22),(94,'Quinta de Tilcoco',22),(95,'Rancagua',22),(96,'Requínoa',22),(97,'Rengo',22),(98,'San Francisco de Mostazal',22),(99,'San Vicente de Tagua Tagua',22),(100,'La Estrella',23),(101,'Litueche',23),(102,'Marchigue',23),(103,'Navidad',23),(104,'Paredones',23),(105,'Pichilemu',23),(106,'Chépica',24),(107,'Chimbarongo',24),(108,'Lolol',24),(109,'Nancagua',24),(110,'Palmilla',24),(111,'Peralillo',24),(112,'Placilla',24),(113,'Pumanque',24),(114,'San Fernando',24),(115,'Santa Cruz',24),(116,'Cauquenes',25),(117,'Chanco',25),(118,'Pelluhue',25),(119,'Curicó',26),(120,'Hualañé',26),(121,'Licantén',26),(122,'Molina',26),(123,'Rauco',26),(124,'Romeral',26),(125,'Sagrada Familia',26),(126,'Teno',26),(127,'Vichuquén',26),(128,'Colbún',27),(129,'Linares',27),(130,'Longaví',27),(131,'Parral',27),(132,'Retiro',27),(133,'San Javier de Loncomilla',27),(134,'Villa Alegre',27),(135,'Yerbas Buenas',27),(136,'Constitución',28),(137,'Curepto',28),(138,'Empedrado',28),(139,'Maule',28),(140,'Pelarco',28),(141,'Pencahue',28),(142,'Río Claro',28),(143,'San Clemente',28),(144,'San Rafael',28),(145,'Talca',28),(146,'Arauco',29),(147,'Cañete',29),(148,'Contulmo',29),(149,'Curanilahue',29),(150,'Lebu',29),(151,'Los Álamos',29),(152,'Tirúa',29),(153,'Alto Biobío',30),(154,'Antuco',30),(155,'Cabrero',30),(156,'Laja',30),(157,'Los Ángeles',30),(158,'Mulchen',30),(159,'Nacimiento',30),(160,'Negrete',30),(161,'Quilaco',30),(162,'Quilleco',30),(163,'San Rosendo',30),(164,'Santa Bárbara',30),(165,'Tucapel',30),(166,'Yumbel',30),(167,'Chiguayante',31),(168,'Concepción',31),(169,'Coronel',31),(170,'Florida',31),(171,'Hualpén',31),(172,'Hualqui',31),(173,'Lota',31),(174,'Penco',31),(175,'San Pedro de la Paz',31),(176,'Santa Juana',31),(177,'Talcahuano',31),(178,'Tomé',31),(179,'Bulnes',32),(180,'Chillán',32),(181,'Chillán Viejo',32),(182,'Cobquecura',32),(183,'Coelemu',32),(184,'Coihueco',32),(185,'El Carmen',32),(186,'Ninhue',32),(187,'Ñiquén',32),(188,'Pemuco',32),(189,'Pinto',32),(190,'Portezuelo',32),(191,'Quellón',32),(192,'Quirihue',32),(193,'Ránquil',32),(194,'San Carlos',32),(195,'San Fabián',32),(196,'San Ignacio',32),(197,'San Nicolás',32),(198,'Treguaco',32),(199,'Yungay',32),(200,'Carahue',33),(201,'Cholchol',33),(202,'Cunco',33),(203,'Curarrehue',33),(204,'Freire',33),(205,'Galvarino',33),(206,'Gorbea',33),(207,'Lautaro',33),(208,'Loncoche',33),(209,'Melipeuco',33),(210,'Nueva Imperial',33),(211,'Padre Las Casas',33),(212,'Perquenco',33),(213,'Pitrufquén',33),(214,'Pucón',33),(215,'Saavedra',33),(216,'Temuco',33),(217,'Teodoro Schmidt',33),(218,'Toltén',33),(219,'Vilcún',33),(220,'Villarrica',33),(221,'Angol',34),(222,'Collipulli',34),(223,'Curacautín',34),(224,'Ercilla',34),(225,'Lonquimay',34),(226,'Los Sauces',34),(227,'Lumaco',34),(228,'Purén',34),(229,'Reinaco',34),(230,'Traiguén',34),(231,'Victoria',34),(232,'Futrono',35),(233,'La Unión',35),(234,'Lago Ranco',35),(235,'Rio Bueno',35),(236,'Corral',36),(237,'Lanco',36),(238,'Los Lagos',36),(239,'Máfil',36),(240,'Mariquina',36),(241,'Paillaco',36),(242,'Panguipulli',36),(243,'Valdivia',36),(244,'Ancud',37),(245,'Castro',37),(246,'Chonchi',37),(247,'Curaco de Vélez',37),(248,'Dalcahue',37),(249,'Puqueldón',37),(250,'Queilén',37),(251,'Quellón',37),(252,'Quemchi',37),(253,'Quinchao',37),(254,'Calbuco',38),(255,'Cochamó',38),(256,'Fresia',38),(257,'Frutillar',38),(258,'Llanquihue',38),(259,'Los Muermos',38),(260,'Maullín',38),(261,'Puerto Montt',38),(262,'Puerto Varas',38),(263,'Osorno',39),(264,'Puerto Octay',39),(265,'Purranque',39),(266,'Puyehue',39),(267,'Río Negro',39),(268,'San Pablo',39),(269,'San Juan de la Costa',39),(270,'Chaitén',40),(271,'Futaleufú',40),(272,'Hualaihué',40),(273,'Palena',40),(274,'Aysén',41),(275,'Cisnes',41),(276,'Guaitecas',41),(277,'Cochrane',42),(278,'O\'Higgins',42),(279,'Tortel',42),(280,'Coyhaique',43),(281,'Lago Verde',43),(282,'Chile Chico',44),(283,'Río Ibáñez',44),(284,'Antártica',45),(285,'Cabo de Hornos',45),(286,'Laguna Blanca',46),(287,'Punta Arenas',46),(288,'Río Verde',46),(289,'San Gregorio',46),(290,'Porvenir',47),(291,'Primavera',47),(292,'Timaukel',47),(293,'Natales',48),(294,'Torres del Paine',48),(295,'Colina',49),(296,'Lampa',49),(297,'Tiltil',49),(298,'Pirque',50),(299,'Puente Alto',50),(300,'San José de Maipo',50),(301,'Buin',51),(302,'Calera de Tango',51),(303,'Paine',51),(304,'San Bernardo',51),(305,'Alhué',52),(306,'Curacaví',52),(307,'María Pinto',52),(308,'Melipilla',52),(309,'San Pedro',52),(310,'Cerillos',53),(311,'Cerro Navia',53),(312,'Conchalí',53),(313,'El Bosque',53),(314,'Estación Central',53),(315,'Huechuraba',53),(316,'Independencia',53),(317,'La Cisterna',53),(318,'La Granja',53),(319,'La Florida',53),(320,'La Pintana',53),(321,'La Reina',53),(322,'Las Condes',53),(323,'Lo Barnechea',53),(324,'Lo Espejo',53),(325,'Lo Prado',53),(326,'Macul',53),(327,'Maipú',53),(328,'Ñuñoa',53),(329,'Pedro Aguirre Cerda',53),(330,'Peñalolén',53),(331,'Providencia',53),(332,'Pudahuel',53),(333,'Quilicura',53),(334,'Quinta Normal',53),(335,'Recoleta',53),(336,'Renca',53),(337,'San Miguel',53),(338,'San Joaquín',53),(339,'San Ramón',53),(340,'Santiago',53),(341,'Vitacura',53),(342,'El Monte',54),(343,'Isla de Maipo',54),(344,'Padre Hurtado',54),(345,'Peñaflor',54),(346,'Talagante',54);
/*!40000 ALTER TABLE `comuna` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pais`
--

DROP TABLE IF EXISTS `pais`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pais` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pais`
--

LOCK TABLES `pais` WRITE;
/*!40000 ALTER TABLE `pais` DISABLE KEYS */;
INSERT INTO `pais` VALUES (1,'Chile');
/*!40000 ALTER TABLE `pais` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `provincia` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `capital_provincial` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `id_region` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `provincia`
--

LOCK TABLES `provincia` WRITE;
/*!40000 ALTER TABLE `provincia` DISABLE KEYS */;
INSERT INTO `provincia` VALUES (1,'Arica','Arica',1),(2,'Parinacota','Putre',1),(3,'Iquique','Iquique',2),(4,'Tamarugal','Pozo Almonte',2),(5,'Antofagasta','Antofagasta',3),(6,'El Loa','Calama',3),(7,'Tocopilla','Tocopilla',3),(8,'Chañaral','Chañaral',4),(9,'Copiapó','Copiapó',4),(10,'Huasco','Vallenar',4),(11,'Choapa','Illapel',5),(12,'Elqui','Coquimbo',5),(13,'Limarí','Ovalle',5),(14,'Isla de Pascua','Hanga Roa',6),(15,'Los Andes','Los Andes',6),(16,'Marga Marga','Quilpué',6),(17,'Petorca','La Ligua',6),(18,'Quillota','Quillota',6),(19,'San Antonio','San Antonio',6),(20,'San Felipe de Aconcagua','San Felipe',6),(21,'Valparaíso','Valparaíso',6),(22,'Cachapoal','Rancagua',7),(23,'Cardenal Caro','Pichilemu',7),(24,'Colchagua','San Fernando',7),(25,'Cauquenes','Cauquenes',8),(26,'Curicó','Curicó',8),(27,'Linares','Linares',8),(28,'Talca','Talca',8),(29,'Arauco','Lebu',9),(30,'Biobió','Los Angeles',9),(31,'Concepción','Concepción',9),(32,'Ñuble','Chillán',9),(33,'Cautín','Temuco',10),(34,'Malleco','Angol',10),(35,'Ranco','La Únion',11),(36,'Valdivia','Valdivia',11),(37,'Chiloé','Castro',12),(38,'Llanquihue','Puerto Montt',12),(39,'Osorno','Osorno',12),(40,'Palena','Chaitén',12),(41,'Aysén','Puerto Aysén',13),(42,'Capitán Prat','Cochrane',13),(43,'Coyhaique','Coyhaique',13),(44,'General Carrera','Chile Chico',13),(45,'Antártica Chilena','Puerto Williams',14),(46,'Magallanes','Punta Arenas',14),(47,'Tierra del Fuego','Porvenir',14),(48,'Última Esperanza','Puerto Natales',14),(49,'Chacabuco','Colina',15),(50,'Cordillera','Puente Alto',15),(51,'Maipo','San Bernardo',15),(52,'Melipilla','Melipilla',15),(53,'Santiago','Santiago',15),(54,'Talagante','Talagante',15);
/*!40000 ALTER TABLE `provincia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(200) COLLATE latin1_spanish_ci NOT NULL,
  `numero` varchar(10) COLLATE latin1_spanish_ci NOT NULL,
  `capital_regional` varchar(20) COLLATE latin1_spanish_ci NOT NULL,
  `id_pais` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` VALUES (1,'Arica y Parinacota','XV','Arica',1),(2,'Tarapacá','I','Iquique',1),(3,'Antofagasta','II','Antofagasta',1),(4,'Atacama','III','Copiapó',1),(5,'Coquimbo','IV','La Serena',1),(6,'Valparaíso','V','Valparaíso',1),(7,'Libertador General Bernardo O\'Higgins','VI','Rancagua',1),(8,'Maule','VII','Talca',1),(9,'Biobío','VIII','Concepción',1),(10,'Araucanía','IX','Temuco',1),(11,'Los Ríos','XIV','Valdivia',1),(12,'Los Lagos','X','Puerto Montt',1),(13,'Aysén del General Carlos Ibáñez del Campo','XI','Coyhaique',1),(14,'Magallanes y de la Antártica Chilena','XII','Punta Arenas',1),(15,'Metropolitana de Santiago','XIII','Santiago',1);
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-28 10:40:08
