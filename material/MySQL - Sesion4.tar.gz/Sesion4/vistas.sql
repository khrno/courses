CREATE VIEW ocurrencias_artistas AS
SELECT gs.name,count(*) AS qty 
FROM episode_guest_star AS egs 
INNER JOIN guest_star AS gs 
ON gs.id = egs.id_guest_star 
GROUP BY gs.name 
ORDER BY qty DESC;

CREATE VIEW escritores_por_episodio AS
SELECT e.episode_name,count(*) AS qty 
FROM episode AS e 
INNER JOIN episode_writer AS ew 
ON ew.id_episode = e.id 
GROUP BY e.episode_name 
ORDER BY qty DESC;