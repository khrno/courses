CREATE VIEW ocurrencias_artistas AS
SELECT gs.name,count(*) AS qty 
FROM episode_guest_star AS egs 
INNER JOIN guest_star AS gs 
ON gs.id = egs.id_guest_star 
GROUP BY gs.name 
ORDER BY qty DESC;

CREATE VIEW escritores_por_episodio AS
SELECT e.id as id_episode, e.episode_name as episode_name,count(*) AS qty_escritores 
FROM episode AS e 
INNER JOIN episode_writer AS ew 
ON ew.id_episode = e.id 
GROUP BY e.episode_name 
ORDER BY qty DESC;

CREATE VIEW guest_stars_por_episodio AS
SELECT e.id as id_episode, e.episode_name as episode_name,count(*) AS qty_guest_stars 
FROM episode AS e 
INNER JOIN episode_guest_star as egs 
ON egs.id_episode = e.id 
GROUP BY e.episode_name 
ORDER BY qty_guest_stars DESC;

--Query
SELECT s.number AS temporada, results_escritores.escritores, results_estrellas.estrellas 
FROM 
(
	SELECT e.id_season, SUM(qty_escritores) AS escritores 
	FROM episode AS e LEFT OUTER JOIN escritores_por_episodio AS epe ON e.id = epe.id_episode GROUP BY e.id_season 
	UNION 
	SELECT e.id_season, SUM(qty_escritores) AS escritores
	FROM episode AS e RIGHT OUTER JOIN escritores_por_episodio AS epe ON e.id = epe.id_episode GROUP BY e.id_season
) AS results_escritores 
LEFT OUTER JOIN 
(
	SELECT e.id_season, SUM(qty_guest_stars) AS estrellas 
	FROM episode AS e LEFT OUTER JOIN guest_stars_por_episodio AS gspe ON e.id = gspe.id_episode GROUP BY e.id_season
	UNION
	SELECT e.id_season, SUM(qty_guest_stars) AS estrellas 
	FROM episode AS e RIGHT OUTER JOIN guest_stars_por_episodio AS gspe ON e.id = gspe.id_episode GROUP BY e.id_season
) AS results_estrellas ON results_escritores.id_season = results_estrellas.id_season, season AS s WHERE s.id = results_estrellas.id_season;


-- First View
CREATE VIEW escritores_por_temporada AS
SELECT e.id_season, SUM(qty_escritores) AS escritores 
FROM episode AS e LEFT OUTER JOIN escritores_por_episodio AS epe ON e.id = epe.id_episode GROUP BY e.id_season 
UNION 
SELECT e.id_season, SUM(qty_escritores) AS escritores
FROM episode AS e RIGHT OUTER JOIN escritores_por_episodio AS epe ON e.id = epe.id_episode GROUP BY e.id_season;

-- Second View
CREATE VIEW estrellas_por_temporada AS
SELECT e.id_season, SUM(qty_guest_stars) AS estrellas 
FROM episode AS e LEFT OUTER JOIN guest_stars_por_episodio AS gspe ON e.id = gspe.id_episode GROUP BY e.id_season
UNION
SELECT e.id_season, SUM(qty_guest_stars) AS estrellas 
FROM episode AS e RIGHT OUTER JOIN guest_stars_por_episodio AS gspe ON e.id = gspe.id_episode GROUP BY e.id_season;

-- THE VIEW
CREATE VIEW escritores_estrellas_por_temporada AS
SELECT s.number AS temporada, escritorespt.escritores, estrellaspt.estrellas 
FROM escritores_por_temporada AS escritorespt 
LEFT OUTER JOIN estrellas_por_temporada AS estrellaspt ON escritorespt.id_season = estrellaspt.id_season 
INNER JOIN season AS s ON s.id = escritorespt.id_season;



