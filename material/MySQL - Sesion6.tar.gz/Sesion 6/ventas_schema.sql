CREATE TABLE IF NOT EXISTS tipo_pago(
	id integer PRIMARY KEY AUTO_INCREMENT,
	tipo varchar(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS producto(
	id integer PRIMARY KEY AUTO_INCREMENT,
	nombre varchar(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS pais(
	id integer PRIMARY KEY AUTO_INCREMENT,
	nombre varchar(200) NOT NULL
);

CREATE TABLE IF NOT EXISTS estado(
	id integer PRIMARY KEY AUTO_INCREMENT,
	nombre varchar(200) NOT NULL,
	id_pais integer NOT NULL REFERENCES pais(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS ciudad(
	id integer PRIMARY KEY AUTO_INCREMENT,
	nombre varchar(200) NOT NULL,
	lat float NOT NULL,
	lng float NOT NULL,
	id_estado integer NOT NULL REFERENCES estado(id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS usuario(
	id integer PRIMARY KEY AUTO_INCREMENT,
	nombre varchar(200) NOT NULL,
	fecha_creacion datetime NOT NULL,
	ultimo_acceso datetime NOT NULL,
	id_ciudad integer NOT NULL REFERENCES ciudad(id) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS transaccion(
	id integer PRIMARY KEY AUTO_INCREMENT,
	fecha datetime NOT NULL,
	id_tipo_pago integer REFERENCES tipo_pago(id) ON DELETE SET NULL ON UPDATE CASCADE,
	id_producto integer REFERENCES producto(id) ON DELETE SET NULL ON UPDATE CASCADE,
	id_usuario integer REFERENCES usuario(id) ON DELETE SET NULL ON UPDATE CASCADE
);
	