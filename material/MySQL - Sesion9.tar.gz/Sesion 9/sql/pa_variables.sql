DECLARE variable_name datatype(size) 
	DEFAULT default_value;
DECLARE total_sale INT DEFAULT 0;
DECLARE x, y INT DEFAULT 0;
DECLARE total_count INT DEFAULT 0;
SET total_count = 10;
SELECT COUNT(*) INTO total_products
	FROM products;