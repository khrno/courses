DELIMITER $$
 
CREATE FUNCTION CustomerLevel(p_creditLimit double) 
  RETURNS VARCHAR(10)
  DETERMINISTIC
BEGIN
  DECLARE lvl varchar(10);

  IF p_creditLimit > 50000 THEN
    SET lvl = 'PLATINUM';
  ELSEIF (p_creditLimit <= 50000 AND 
  	p_creditLimit >= 10000) THEN
    SET lvl = 'GOLD';
  ELSEIF p_creditLimit < 10000 THEN
    SET lvl = 'SILVER';
  END IF;

  RETURN (lvl);
END
DELIMITER;

SELECT customerName,
  CustomerLevel(creditLimit)
FROM customers;

DELIMITER $$
 
CREATE PROCEDURE GetCustomerLevel(
  IN  p_customerNumber INT(11),
  OUT p_customerLevel  varchar(10)
)
BEGIN
  DECLARE creditlim DOUBLE;
 
  SELECT creditlimit INTO creditlim
  FROM customers
  WHERE customerNumber = p_customerNumber;
 
  SELECT CUSTOMERLEVEL(creditlim) 
  INTO p_customerLevel;
 
END
DELIMITER;