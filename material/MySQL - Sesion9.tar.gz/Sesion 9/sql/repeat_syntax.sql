REPEAT
Statements;
UNTIL expression
END REPEAT