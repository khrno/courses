WHILE expression DO
   Statements
END WHILE