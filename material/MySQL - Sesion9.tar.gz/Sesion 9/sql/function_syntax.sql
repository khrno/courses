CREATE FUNCTION functionName(param1,param2,...)
    RETURNS datatype
   [NOT] DETERMINISTIC
 statements