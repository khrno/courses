DELIMITER $$
 DROP PROCEDURE IF EXISTS RepeatLoopProc$$
 CREATE PROCEDURE RepeatLoopProc()
   BEGIN
     DECLARE x INT DEFAULT 1;
     DECLARE str  VARCHAR(255) DEFAULT '';
     REPEAT
       SET  str = CONCAT(str,x,',');
       SET  x = x + 1; 
     UNTIL x  > 5
     END REPEAT;
     SELECT str;
   END$$
 DELIMITER ;