DELIMITER $$
CREATE PROCEDURE set_counter(
	INOUT count INT(4),
	IN inc INT(4))
BEGIN
 SET count = count + inc;
END$$
DELIMITER ;
SET @counter = 1;
CALL set_counter(@counter,1); -- 2
CALL set_counter(@counter,1); -- 3
CALL set_counter(@counter,5); -- 8
SELECT @counter; -- 8