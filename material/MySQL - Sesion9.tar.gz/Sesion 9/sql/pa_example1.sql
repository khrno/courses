DELIMITER //
	CREATE PROCEDURE GetAllProducts()
		BEGIN
		SELECT *  FROM products;
	END //
DELIMITER ;
CALL GetAllProducts();