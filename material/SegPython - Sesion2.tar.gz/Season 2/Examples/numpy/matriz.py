import numpy as np



m = np.random.rand(3,2)
m2 = np.random.rand(3,2)
print "M"
print m
print "M2"
print m2
print "M * M2"
print m*m2