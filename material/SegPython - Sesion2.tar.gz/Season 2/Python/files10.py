#!/usr/bin/python
import os

# Renombramos codehero.txt por codehero2.txt
os.rename( "codehero.txt", "codehero2.txt" )