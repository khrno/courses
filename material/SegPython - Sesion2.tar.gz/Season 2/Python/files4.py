#!/usr/bin/python

# Abrimos el archivo codehero.txt
fo = open("codehero.txt", "wb")
print "Nombre del archivo: ", fo.name

# Cerramos el archivo codehero.txt
fo.close()