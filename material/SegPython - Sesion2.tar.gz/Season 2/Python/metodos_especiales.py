class A:
	def __init__(self, args):
		pass
	def __del__(self):
		pass
	def __str__(self):
		pass
	def __cmp__(self, otro):
		pass
	def __len__(self):
		pass
	...