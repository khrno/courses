class Hija(Padre):
    def __init__(self):
        print("Constructor de la clase hija")
    
    def metodoHija(self):
        print("Metodo clase hija")
 