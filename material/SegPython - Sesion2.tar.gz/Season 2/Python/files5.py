#!/usr/bin/python

objecto_archivo.write(string);