word = "Python"
print word[-1] # n
print word[0:2] # Py
print word[2:5] # tho
print word[:2] # Py
print word[2:] # thon
print word[-2:] # on
