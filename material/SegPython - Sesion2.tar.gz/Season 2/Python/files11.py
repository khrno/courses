#!/usr/bin/python
os.remove(file_name)