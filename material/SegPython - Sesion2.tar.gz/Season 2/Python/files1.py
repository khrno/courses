#!/usr/bin/env python
# -*- coding: utf-8 -*-
objeto_archivo = open(file_name, [, access_mode]
	[, buffering])