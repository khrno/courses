#!/usr/bin/python
# Abrimos el archivo codehero.txt
fo = open("codehero.txt", "r+")
str = fo.read(10)
print fo.read(20)
print "La lectura es : ", str
# Cerramos el archivo codehero.txt
fo.close()