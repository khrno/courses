class Padre():
    def __init__(self):
        self.x = 5;
        print("Constructor de la clase padre")

    def metodo(self):
        print("Ejecutando metodo de clase padre")