class HijaMult(Madre, Padre):
	#HijaMult se parece mas a su Madre que
	#a su padre
    def __init__(self):
        print("Constructor de la clase hija")
    
    def metodoHija(self):
        print("Metodo clase hija")
 