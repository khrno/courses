import modulo1

nombre = "Pepe"
print modulo1.__name__
modulo1.saludar(nombre)
modulo1.despedir(nombre)