#!/usr/bin/env python
#−∗−coding: utf−8−∗−

def saludar(nombre):
	print "Hola %s!" % nombre

def despedir(nombre):
	print "Adios %s!" % nombre

if ( __name__ == "__main__"):
	nombre = raw_input("Ingrese su nombre: ")
	saludar(nombre)
	despedir(nombre)