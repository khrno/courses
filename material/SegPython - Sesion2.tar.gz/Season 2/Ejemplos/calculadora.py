
def sumar(a,b):
	print "%d + %d = %d" % (a,b,a+b)

def restar(a,b):
	print "%d - %d = %d" % (a,b,a-b)

def multiplicar(a,b):
	print "%d * %d = %d" % (a,b,a*b)

def dividir(a,b):
	print "%d / %d = %d" % (a,b,a/b)


if __name__ == "__main__":
	a = 2
	b = 2
	sumar(a,b)
	restar(a,b)
	multiplicar(a,b)
	dividir(a,b)