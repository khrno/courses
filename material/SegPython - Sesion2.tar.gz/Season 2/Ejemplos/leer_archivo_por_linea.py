fo = open("numeros.txt", "rb")

for line in fo.readlines():
	print line,
	#con la linea evito que print agregue un \n al final de la linea
