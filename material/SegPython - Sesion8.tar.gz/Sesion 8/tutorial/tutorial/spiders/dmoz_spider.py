import scrapy
from tutorial.items import DmozItem
class DmozSpider(scrapy.Spider):
	name = "dmoz"
	allowed_domains = ["dmoz.org"]
	start_urls = [
		"http://www.dmoz.org/Computers/Programming/Languages/Python/Books/",
		# "http://www.dmoz.org/Computers/Programming/Languages/Python/Resources/"
	]

	def parse(self, response):
		for sel in response.css('ul.directory-url > li'):
			item = DmozItem()
			item['title'] = sel.css('a::text').extract()[0]
			item['link'] = sel.css('a::attr("href")').extract()[0]
			yield item
