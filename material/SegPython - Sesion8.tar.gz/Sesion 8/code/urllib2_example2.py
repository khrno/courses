import urllib2
import urllib
'''
Objetivo
---------
Enviar peticiones POST
'''

# Se construye la query que se desea enviar
query = {"q":"miquery"}
data = urllib.urlencode(query)
print data

# Se construye el request utilizando la query anterior
url = "http://localhost"
request = urllib2.Request(url, data)

# Se envia el request y se almacena la respuesta en response
response = urllib2.urlopen(request)

# Se lee la respuesta y se almacena en html
html = response.read()

# Se muestra html
print html