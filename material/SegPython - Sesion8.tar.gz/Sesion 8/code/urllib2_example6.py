import urllib2
'''
Objetivo
---------
Cambiar el User-Agent
'''
# Define the url
url = 'http://localhost/'

userAgents = {
	'Safari':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/600.8.9 (KHTML, like Gecko) Version/8.0.8 Safari/600.8.9',
	'Chrome': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.99 Safari/537.36',
	'Firefox': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:38.0) Gecko/20100101 Firefox/38.0',
	'Opera': 'Opera/9.80 (Macintosh; Intel Mac OS X 10.10.5) Presto/2.12.388 Version/12.16'
}


request = urllib2.Request(url)
# Getting the response
response = urllib2.urlopen(request)

# Print the headers
print response.headers

for k in userAgents.keys():
	# Add your headers
	headers = {'User-Agent' : userAgents[k]}

	# Create the Request. 
	request = urllib2.Request(url, None, headers)

	# Getting the response
	response = urllib2.urlopen(request)

	# Print the headers
	print response.headers