import urllib2
import urllib
import ssl
'''
Objetivo
---------
Extender urllib2 para enviar peticiones PUT
Observacion: un poco tricky en la clase
'''

class MyRequestExtended(urllib2.Request):
	def __init__(self, *args, **kwargs):
		if 'method' in kwargs:
			self._method = kwargs['method']
			del kwargs['method']
		else:
			self._method = None
		return urllib2.Request.__init__(self, *args, **kwargs)

	def get_method(self, *args, **kwargs):
		if self._method is not None:
			return self._method
		return urllib2.Request.get_method(self, *args, **kwargs)

if __name__=="__main__":
	# Se construye la query que se desea enviar
	query = {"q":"miquery"}
	data = urllib.urlencode(query)
	# print data

	# Se construye el request utilizando la query anterior
	url = "http://www.fach.mil.cl"
	request = MyRequestExtended(url, data, method="OPTIONS")

	# Se envia el request y se almacena la respuesta en response
	response = urllib2.urlopen(request)
	headers = response.info()
	print headers
	# Se lee la respuesta y se almacena en html
	html = response.read()

	# Se muestra html
	print html