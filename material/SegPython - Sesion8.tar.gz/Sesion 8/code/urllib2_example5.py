import urllib2
'''
Objetivo
---------
Descargando archivos con urllib2
'''
url = "http://localhost/~pablo/urllib2_folder/song.mp3"
output_filename = "cancion.mp3"


response = urllib2.urlopen(url)

output = open(output_filename,"wb")
output.write(response.read())
output.close()
