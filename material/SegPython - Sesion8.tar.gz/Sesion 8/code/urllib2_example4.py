import urllib
import urllib2
'''
Objetivo
---------
Diferenciar cuando se pasa de metodo GET a metodo PUT
'''
query_args = { 'q':'query string', 'foo':'bar' }

request = urllib2.Request('http://localhost/')
print 'Request method before data:', request.get_method()

request.add_data(urllib.urlencode(query_args))
print 'Request method after data :', request.get_method()