import scrapy
from urlparse import urljoin

class Post(scrapy.Item):
	title = scrapy.Field()

class BlogSpider(scrapy.Spider):
	name,start_urls = "blogspider", ["http://blog.scrapinghub.com"]
	def parse(self, response):
		for url in response.css('ul li a::attr("href")').re(r'.*/\d\d\d\d/\d\d/$'):
			yield scrapy.Request(urljoin(response.url,url), self.parse_titles)

	def parse_titles(self, response):
		for post_title in response.css('div.entries > ul > li a::text').extract():
			yield Post(title=post_title)