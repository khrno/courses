from example2 import app
app.run(debug=True)