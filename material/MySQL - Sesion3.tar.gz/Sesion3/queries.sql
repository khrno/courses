--INNER JOIN
	SELECT A.*, B.*, C.*
	FROM tabla_a AS A
	INNER JOIN tabla_b AS B ON A.id = B.id
	INNER JOIN tabla_c AS C ON B.id = C.id;

	SELECT A.*, B.*, C.*
	FROM tabla_a AS A
	INNER JOIN tabla_b AS B ON A.id = B.id
	INNER JOIN tabla_c AS C ON A.id = C.id;

	SELECT r.*, C.*
	FROM (
	SELECT A.id as aid, A.value as avalue,B.*
	FROM tabla_a AS A 
	INNER JOIN tabla_b AS B ON A.id = B.id
	) as r INNER JOIN tabla_c as C ON r.aid = C.id; 

	SELECT r.*, A.*
	FROM (
	SELECT B.id as bid, B.value as bvalue,B.*
	FROM tabla_b AS B 
	INNER JOIN tabla_c AS C ON B.id = C.id
	) as r INNER JOIN tabla_a as A ON r.bid = A.id; 


--LEFT JOIN
	SELECT A.*, B.*, C.*
	FROM tabla_a as A
	LEFT JOIN tabla_b as B ON A.id = B.id
	LEFT JOIN tabla_c as C ON A.id = C.id;

	SELECT R.*, C.*
	FROM tabla_c AS C LEFT JOIN (
	SELECT A.id as aid, A.value as avalue, B.*
	FROM tabla_b as B LEFT JOIN tabla_a as A on B.id = A.id
	) as R ON r.aid = c.id;



-- RIGHT JOIN
	SELECT A.*, B.*, C.*
	FROM tabla_c as C
	RIGHT JOIN tabla_a as A ON A.id = C.id
	RIGHT JOIN tabla_b as B on B.id = C.id;

	SELECT R.*,C.*
	FROM (
	SELECT A.ID as aid, A.value as avalue, B.*
	FROM tabla_a as A RIGHT JOIN tabla_b as B ON A.id=B.id
	) as R right join tabla_c as C on r.aid = c.id;

-- OUTER JOIN
	SELECT r.*, c.* FROM
		(SELECT A.id AS aid, A.value AS avalue, B.*
		FROM tabla_a AS A 
		LEFT OUTER JOIN tabla_b AS B ON A.id = B.id
		UNION
		SELECT A.id AS aid, A.value AS avalue, B.*
		FROM tabla_a AS A 
		RIGHT OUTER JOIN tabla_b AS B ON A.id = B.id) AS r
	LEFT OUTER JOIN tabla_c AS C ON c.id = r.aid
UNION
	SELECT r.*, c.* FROM
		(SELECT A.id AS aid, A.value AS avalue, B.*
		FROM tabla_a AS A 
		LEFT OUTER JOIN tabla_b AS B ON A.id = B.id
		UNION
		SELECT A.id AS aid, A.value AS avalue, B.*
		FROM tabla_a AS A 
		RIGHT OUTER JOIN tabla_b AS B ON A.id = B.id) AS r
	RIGHT OUTER JOIN tabla_c AS C ON c.id = r.aid

--- Left Excluding Join
	SELECT C.*, R.*
	FROM tabla_c as C LEFT JOIN (
	SELECT A.id AS aid, A.value AS avalue, B.*
	FROM tabla_a AS A LEFT JOIN tabla_b AS B ON A.id = B.id
	WHERE B.id IS NULL) as R ON C.id = R.aid
	WHERE r.aid IS NULL;


--Outer Excluding Join
SELECT r.*, c.* FROM
(
SELECT A.id AS aid, A.value AS avalue, B.*
FROM tabla_a AS A 
LEFT OUTER JOIN tabla_b AS B ON A.id = B.id
WHERE B.id IS NULL
UNION
SELECT A.id AS aid, A.value AS avalue, B.*
FROM tabla_a AS A 
RIGHT OUTER JOIN tabla_b AS B ON A.id = B.id
WHERE A.id IS NULL
) AS r
LEFT OUTER JOIN tabla_c AS C ON c.id = r.id
WHERE C.id IS NULL
UNION
SELECT r.*, c.* FROM
(
SELECT A.id AS aid, A.value AS avalue, B.*
FROM tabla_a AS A 
LEFT OUTER JOIN tabla_b AS B ON A.id = B.id
WHERE B.id IS NULL
UNION
SELECT A.id AS aid, A.value AS avalue, B.*
FROM tabla_a AS A 
RIGHT OUTER JOIN tabla_b AS B ON A.id = B.id
WHERE A.id IS NULL
) AS r
RIGHT OUTER JOIN tabla_c AS C ON c.id = r.id
WHERE r.id IS NULL


