CREATE TABLE employees_audit ( 
    id int(11) NOT NULL AUTO_INCREMENT, 
    employeeNumber int(11) NOT NULL, 
    lastname varchar(50) NOT NULL, 
    changedon datetime DEFAULT NULL, 
    action varchar(50) DEFAULT NULL, 
    PRIMARY KEY (id) 
 )