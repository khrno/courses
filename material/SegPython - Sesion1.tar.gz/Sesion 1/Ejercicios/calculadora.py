#!/usr/bin/env python
# -*- coding: utf-8 -*-





def ejecutar_operacion(operador):
	if operador == "sumar":
		try:
			valor1 = int(raw_input("Ingrese el primer sumando: "))
			valor2 = int(raw_input("Ingrese el segundo sumando: "))
			print "\t\tSumar"
			print "\t\t+++++"
			print "\t\t%d + %d = %d" % (valor1, valor2, valor1+valor2)
		except ValueError:
			print "Valor inválido"
	elif operador == "restar":
		try:
			valor1 = int(raw_input("Ingrese el primer valor: "))
			valor2 = int(raw_input("Ingrese el segundo valor: "))
			print "\t\tRestar"
			print "\t\t+++++"
			print "\t\t%d - %d = %d" % (valor1, valor2, valor1-valor2)
		except ValueError:
			print "Valor inválido"
	elif operador == "multiplicar":
		try:
			valor1 = int(raw_input("Ingrese el primer factor: "))
			valor2 = int(raw_input("Ingrese el segundo factor: "))
			print "\t\tMultiplicar"
			print "\t\t+++++++++++"
			print "\t\t%d * %d = %d" % (valor1, valor2, valor1*valor2)
		except ValueError:
			print "Valor inválido"
	elif operador == "dividir":
		try:
			valor1 = int(raw_input("Ingrese el primer factor: "))
			valor2 = int(raw_input("Ingrese el segundo factor: "))
			print "\t\tMultiplicar"
			print "\t\t+++++++++++"
			print "\t\t%d / %d = %d" % (valor1, valor2, valor1/valor2)
		except ValueError:
			print "Valor inválido"
		except ZeroDivisionError:
			print "No puedes dividir por 0"
	elif operador == "elevar":
		try:
			valor1 = int(raw_input("Ingrese el primer factor: "))
			valor2 = int(raw_input("Ingrese el segundo factor: "))
			print "\t\tElevar"
			print "\t\t+++++++++++"
			print "\t\t%d ^ %d = %d" % (valor1, valor2, valor1/valor2)
		except ValueError:
			print "Valor inválido"
	elif operador == "sumatoria":
		try:
			valor1 = int(raw_input("Ingrese hasta que número sumar: "))
			resultado = (valor1+1)*valor1/2
			# resultado = valor1*resultado
			# resultado = resultado/2
			print "\t\tSumatoria"
			print "\t\t+++++++++++"
			print "\t\tSumatoria de i hasta %d = %d" % (valor1, resultado)
		except ValueError:
			print "Valor inválido"


def show_main_menu():
	print "\t+++++++++++++++++++++++"
	print "\tCalculadora de Bolsillo"
	print "\t+++++++++++++++++++++++"

	option = -1
	while option != 7:
		try:
			print "\tOpciones"
			print "1.\t Sumar"
			print "2.\t Restar"
			print "3.\t Multiplicar"
			print "4.\t Dividr"
			print "5.\t Elevar"
			print "6.\t Sumatoria"
			print "7.\t Salir"

			option = int(raw_input("Ingrese su opción: "))
			if option>=1 and option<=7:
				if option==1:
					ejecutar_operacion("sumar")
				elif option==2:
					ejecutar_operacion("restar")
				elif option==3:
					ejecutar_operacion("multiplicar")
				elif option==4:
					ejecutar_operacion("dividir")
				elif option==5:
					ejecutar_operacion("elevar")
				elif option==6:
					ejecutar_operacion("sumatoria")

			else:
				print "Valor inválido"
			
		except ValueError:
			print "Valor inválido"


show_main_menu()