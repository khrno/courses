#Metodo 1 - Utilizando bucles y funciones



def caracter_es_alfanumerico(c):
	abecedario = "abcdefghijklmnopqrstuvwyz"
	abecedarioMayus = "ABCDEFGHIJKLMNOPQRSTUVWYZ"
	digitos = "1234567890"
	for letter in abecedario:
		if c==letter:
			return True
	for letter in abecedarioMayus:
		if c==letter:
			return True
	for digito in digitos:
		if c==digito:
			return True
	return False










nombre = raw_input("Ingrese nombre de usuario: ")
cont = 0



for c in nombre:
	if not caracter_es_alfanumerico(c):
		print "El nombre de usuario debe ser alfanumerico"
		exit(1)
	cont += 1

if cont>=6 and cont<=12:
	print "Nombre valido"
else:
	print "Nombre invalido"