# #utilizando bucles for
# for i in range(1,13):
# 	print "Tabla del %d" % i
# 	for j in range(1,13):
# 		print i,"*",j,"=",i*j

# #utilizando listas
# lista = [1,2,3,4,5,6,7,8,9,10,11,12]
# for i in lista:
# 	print "Tabla del %d" % i
# 	for j in lista:
# 		print i,"*",j,"=",i*j
# 		print "%d * %d = %d" % (i,j,i*j)

# utilizando funciones
def multiplicador(factor1, factor2):
	return factor1*factor2
i = 1
while i <= 12:
	j = 1
	print "Tabla del %d" % i
	while j <= 12:
		producto = multiplicador(i,j)
		print "%d * %d = %d" % (i,j,producto)
		j += 1  # j = j +1
	i += 1 # i = i + 1