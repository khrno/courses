#Metodo 2 - Utilizando exceptions




nombre = raw_input("Ingrese nombre de usuario: ")

try:
	sexta_letra = nombre[5]
except IndexError:
	print "Nombre muy corto"
	exit(1)

valido = False
try:
	letra_trece = nombre[12]
except IndexError:
	valido = True

if not valido:
	print "Nombre muy largo"
	exit(1)

abecedario = "abcdefghijklmnopqrstuvwyz"
abecedarioMayus = "ABCDEFGHIJKLMNOPQRSTUVWYZ"
digitos = "1234567890"

valido = False
for c in nombre:
	if c in abecedario or c in abecedarioMayus or c in digitos:
		valido = True
	else:
		print "Nombre invalido"
		exit(1)
if valido:
	print "Nombre valido"
