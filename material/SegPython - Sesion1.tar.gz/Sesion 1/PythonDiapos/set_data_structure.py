#!/usr/bin/python
plato = set(['pastel', 'empanada', 'queso'])
print plato 
# set(['queso', 'pastel', 'empanada'])
print type(plato) # <type 'set'>
bebida = ['cerveza', 'jugo', 'cafe', 'cerveza']
print type(bebida) # <type 'list'>

# establece un conjunto a una variable
para_beber = set(bebida)
print para_beber 
# set(['cafe', 'cerveza', 'jugo'])
print type(para_beber) # <type 'set'>