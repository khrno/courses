#!/usr/bin/python
# Otra forma
def calcular_iva2(monto):
	iva = 19
	return monto * iva / 100

costo = input("Cual es le nuevo monto? ")
print calcular_iva2(costo)
print costo+calcular_iva2(costo)