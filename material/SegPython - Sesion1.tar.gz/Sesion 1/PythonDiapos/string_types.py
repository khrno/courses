#!/usr/bin/python
cadena1 = "esta es una cadena de texto"
cadena2 = 'esta es otra cadena de texto'
cadena3 = """
Esta es otra cadena de texto
que permite tener multilineas"""