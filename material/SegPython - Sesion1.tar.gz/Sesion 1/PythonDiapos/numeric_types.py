#!/usr/bin/python
entero = 1
real = 0.3145
complejos = 2.1 + 7.8j