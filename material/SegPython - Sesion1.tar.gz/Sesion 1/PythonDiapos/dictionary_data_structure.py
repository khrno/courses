#!/usr/bin/python
datos_basicos = {
	"nombres":"Pablo Antonio",
	"apellidos":"Ortega Mesa",
}
datos_basicos["nombres"]
#"Pablo Antonio"

datos_basicos.keys()
datos_basicos.values()
print datos_basicos.items()
