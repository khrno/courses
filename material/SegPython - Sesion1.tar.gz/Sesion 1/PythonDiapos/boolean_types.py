#!/usr/bin/python
valor_verdadero = True
valor_falso = False
resultado1 = valor_verdadero and valor_falso
# resultado1 is False
resultado2 = valor_verdadero or valor_falso
# resutlado2 is True
resultado3 = not valor_falso
# resultado3 is True