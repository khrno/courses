#!/usr/bin/python
for numero in range(1,11):
	print numero

lista = [1,2,3,"cuatro"]

for elemento in lista:
	print lista

lista_tupla = [("a1",1),("a2",2),("a3",3)]
for elemento,valor in lista_tupla:
	print elemento,"=>",valor