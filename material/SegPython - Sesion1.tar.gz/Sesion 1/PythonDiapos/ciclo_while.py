#!/usr/bin/python
suma = 0
numero = 1
while numero <= 10:
    suma = numero + suma
    numero = numero + 1
print "La suma es " + str(suma)