#!/usr/bin/python
def calcular_iva():
    iva = 19
    costo = input('Cual es el monto a calcular?: ')
    calculo = costo * iva / 100
    print calculo
calcular_iva()