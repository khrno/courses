#!/usr/bin/python
try:
	x = int(raw_input(u"Por favor ingrese un numero: "))
except ValueError:
	print u"Oops!  No era valido.  Intente nuevamente..."
try:
	r = 10.0/x
	print "10.0/%d = %.5f" % (x,r)
except ZeroDivisionError:
	print "No puedes dividir por zero"
except NameError:
	print "No existe variable x"
	print "Aqui sigue la excepcion"

