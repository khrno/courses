#!/usr/bin/python
a = ['pan', 'huevos', 100, 1234]
a[1] # 'huevos'
a[3] # 1234 
a[1] = 'palta' #no error
print a # ['pan', 'palta', 100, 1234]