#!/usr/bin/python
t = (12345, 54321, 'hola!')
t[1] # 54321
t[0] # 12345
t[0] = "chao" #error
print t