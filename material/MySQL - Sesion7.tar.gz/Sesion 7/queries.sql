SELECT FIRST_NAME as nombre, LAST_NAME as apellidos FROM employees;
SELECT (DEPARTMENT_ID) FROM employees;
SELECT * FROM employees order by LAST_NAME desc;
SELECT JOB_ID,count(*) AS num_jobs FROM employees GROUP BY JOB_ID ORDER BY num_jobs DESC;
SELECT UPPER(LAST_NAME) from employees;
SELECT FIRST_NAME,LAST_NAME,LENGTH(FIRST_NAME)+LENGTH(LAST_NAME) as largo_nombre FROM employees;
SELECT CONCAT(FIRST_NAME,' ',LAST_NAME) as nombre ,SALARY FROM employees where SALARY < 10000 OR SALARY > 15000;

SELECT FIRST_NAME,LAST_NAME,HIRE_DATE FROM employees WHERE HIRE_DATE LIKE '1987%';

SELECT FIRST_NAME,LAST_NAME,CONCAT(DAYNAME(HIRE_DATE),' ',DAY(HIRE_DATE),' de ',MONTHNAME(HIRE_DATE),' de ',YEAR(HIRE_DATE)) AS HIRE_DATE FROM employees WHERE YEAR(HIRE_DATE) >= 1987;

SELECT CONCAT(FIRST_NAME," ",LAST_NAME) AS nombre, IF(JOB_ID="IT_PROG", "Programmer", "Shipping Clerk") as trabajo, SALARY as salario FROM employees where JOB_ID in ("IT_PROG","SH_CLERK") and SALARY not in (4500,10000,15000);

SELECT departments.DEPARTMENT_NAME, r.STREET_ADDRESS, r.CITY, r.STATE_PROVINCE, r.COUNTRY_NAME FROM departments INNER JOIN  (SELECT locations.LOCATION_ID, locations.STREET_ADDRESS,locations.CITY,locations.STATE_PROVINCE,countries.COUNTRY_NAME FROM locations INNER JOIN countries ON locations.COUNTRY_ID = countries.COUNTRY_ID) AS R ON R.LOCATION_ID = departments.LOCATION_ID; 

SELECT e.FIRST_NAME,e.LAST_NAME, d.DEPARTMENT_ID, d.DEPARTMENT_NAME from employees e INNER JOIN departments d USING (department_id);

SELECT e.FIRST_NAME,e.LAST_NAME, d.DEPARTMENT_ID, d.DEPARTMENT_NAME from employees e INNER JOIN departments d ON d.DEPARTMENT_ID = e.DEPARTMENT_ID;

SELECT departments.department_name, count(*) as num_employees FROM departments INNER JOIN employees ON employees.DEPARTMENT_ID = departments.DEPARTMENT_ID GROUP BY departments.department_name;

SELECT job_history.* FROM job_history INNER JOIN employees ON job_history.EMPLOYEE_ID =  employees.EMPLOYEE_ID WHERE employees.SALARY > 10000;

SELECT * FROM jobs where JOB_ID in ('AC_MGR','AC_ACCOUNT');