import scrapy
import re
from UsProxyListProject.items import UsProxyItem

'''
Esto se ejecuta a traves de python
scrapy crawl usproxy
scrapy crawl usproxy -o resultados.json
'''


class UsProxySpider(scrapy.Spider):
    name = "usproxy"
    allowed_domains = ["us-proxy.org/"]
    start_urls = [
        "http://www.us-proxy.org/"
    ]

    def sanitazeString(self, texto):
        salida = texto.replace("<tr>","")
        salida = salida.replace("<td>","")
        salida = salida.replace("</tr>","")
        salida = salida.replace("</td>","")
        return salida

    def parse(self, response):
        # colsName = ['ip','port','code','country','anonymity','google','https','last_checked']
        # with open("temp.html", "w") as wf:
        #     wf.write(response.body)
        tableElmn = response.xpath('//table[@id="proxylisttable"]/tbody')
        tbodyElmn = tableElmn.xpath('//tbody')
        for row in tbodyElmn.xpath('//tr'):
            item = UsProxyItem()
            cols = row.extract().split("<td>")
            if len(cols)>1:
                item["ip_address"] = self.sanitazeString(cols[1])
                item["port"] = self.sanitazeString(cols[2])
                item["code"] = self.sanitazeString(cols[3])
                item["country"] = self.sanitazeString(cols[4])
                item["anonymity"] = self.sanitazeString(cols[5])
                item["google"] = self.sanitazeString(cols[6])
                item["https"] = self.sanitazeString(cols[7])
                item["last_checked"] = self.sanitazeString(cols[8])
                if len(item["ip_address"]) > 0:
                    yield item
            