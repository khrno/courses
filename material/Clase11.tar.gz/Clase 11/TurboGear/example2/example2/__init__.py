# -*- coding: utf-8 -*-
"""The example2 package"""
