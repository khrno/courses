# -*- coding: utf-8 -*-
"""Controllers for the example2 application."""
