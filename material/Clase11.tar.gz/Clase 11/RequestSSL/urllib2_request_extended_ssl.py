import urllib2
import urllib
import ssl

from request_extended import MyRequestExtended


context = ssl.create_default_context()
context.load_verify_locations(cafile = "IPPUT.pem")

url = "https://bienestar.fach.mil.cl"
request = MyRequestExtended(url, None, method="OPTIONS")

response = urllib2.urlopen(request, context=context)
headers = response.info()
print headers
# Se lee la respuesta y se almacena en html
html = response.read()

# Se muestra html
print html