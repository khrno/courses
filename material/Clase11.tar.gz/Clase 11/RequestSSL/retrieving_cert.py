import ssl
import os

domain = "200.54.67.46"
certFile = "IPPUT.pem"

'''Retrieving the cert file'''
print "Retrieving cert file"
cert = ssl.get_server_certificate((domain,443))

pem_path = os.path.expanduser(certFile)

with open(pem_path, 'a+') as f:
	f.write(cert)