import easywebdav

IP_WEBDAV_SERVER = "ubuntu"
USERNAME = "testuser1"
PASS = "q1w2e3"

webdav = easywebdav.connect(IP_WEBDAV_SERVER, username=USERNAME, password=PASS,protocol='https', port=443, verify_ssl="cacert.pem")

print webdav.ls("webdav")