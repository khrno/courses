import easywebdav

IP_WEBDAV_SERVER = "ubuntu"
USERNAME = "testuser1"
PASS = "q1w2e3"

#Without Authentication -- OK
webdav = easywebdav.connect(IP_WEBDAV_SERVER, protocol='http')
print webdav.ls("webdav")
webdav.upload("sample.local.txt","webdav/sample.curso.1.txt")
webdav.download("webdav/sample.txt", 'sample.local3.txt')
webdav.mkdir("webdav/folder2")
webdav.delete("webdav/sample.curso.1.txt")