from flask import render_template, Flask
app = Flask(__name__)

static_folder = "../static/"


@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
	return render_template('hello.html', 
		name=name, 
		STATIC_URL=static_folder)

@app.route("/")
@app.route("/index")
def index():
	return render_template("index.html",STATIC_URL=static_folder)

if __name__ == "__main__":
	app.run()