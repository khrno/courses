import requests

r = requests.get("http://www.trackip.net/ip?json", 
	proxies={"http": "http://120.206.224.166:8123"})
print r.content