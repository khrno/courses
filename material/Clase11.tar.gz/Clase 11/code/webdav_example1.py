import easywebdav
# Start off by creating a client object. Username and
# password may be omitted if no authentication is needed.
webdav = easywebdav.connect('localhost', username='myuser', password='mypass')
# Do some stuff:
webdav.mkdir('some_dir')
webdav.rmdir('another_dir')
webdav.download('remote/path/to/file', 'local/target/file')
webdav.upload('local/path/to/file', 'remote/target/file')