import urllib2

proxy_url = "http://187.86.182.34:8080"
proxyHandler = urllib2.ProxyHandler({'http': proxy_url})


opener = urllib2.build_opener(proxyHandler)

urllib2.install_opener(opener)

r = urllib2.urlopen("http://www.trackip.net/ip?json")

print r.read()