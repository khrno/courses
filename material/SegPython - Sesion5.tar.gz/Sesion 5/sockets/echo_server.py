import socket

host = "192.168.0.12"
port = 9998

s = socket.socket(socket.AF_INET, 
	socket.SOCK_STREAM)
s.bind((host,port))
s.listen(5)
print "Server is up..."

while True:
	conn,addr = s.accept()
	print type(conn)
	clientaddr = conn.getsockname()
	print "clientaddr:",clientaddr[0]
	print "Client connected at: %s" % str(addr)
	data = conn.recv(1024)
	if not data:
		print "No Data Received"
	conn.sendall(data)
	conn.close()
s.close()