import socket

host = "192.168.0.12"
port = 9999
message = raw_input("Ingres el mensaje: ")

s = socket.socket(socket.AF_INET, 
	socket.SOCK_STREAM)
s.connect((host, port))
s.sendall(message)
data = s.recv(1024)
s.close()
print "Received %s" % repr(data)