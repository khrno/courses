capa_enlace = Ether()
capa_red = IP(dst="192.168.0.31")
capa_transporte = TCP(dport=80)
payload = "Testing scapy"
frame=capa_enlace/capa_red/capa_transporte/payload
send(frame,iface="eth0")
send([frame]*10,iface="eth0")
sr1(frame,iface="eth0")
sr([frame]*10,iface="eth0")
