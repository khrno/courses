ls(IP)
ls(TCP)
ls(UDP)