capa_enlace = Ether()
capa_red = IP(src="5.5.5.5",dst="10.10.10.10")
capa_transporte = TCP(dport = 80, flags = SA)
payload = "Hello World"

frame = capa_enlace/capa_red/capa_transporte/payload