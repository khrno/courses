IP(src="5.5.5.5",dst="192.168.223.1")
cabecera_ip = IP(src="5.5.5.5",dst="192.168.223.1")
cabecera_ip = IP()
cabecera_ip.src="10.7.7.7"
cabecera_ip.dst="10.10.10.10"
ls(cabecera_ip)