traceroute(["www.yahoo.com"],maxttl=20)
traceroute(["www.yahoo.com"],dport=[80,443],maxttl=20)
resp,unans = traceroute(["www.yahoo.com"],
	dport=[80,443],maxttl=20)
resp.graph()