#! /usr/bin/env python

from scapy.all import send, IP, ICMP

send(IP(src="192.168.0.12",dst="192.168.0.31")/ICMP()/"Hello World")