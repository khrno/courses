import easywebdav

IP_WEBDAV_SERVER = "ubuntu"
USERNAME = "testuser1"
PASS = "q1w2e3"

webdav = easywebdav.connect(IP_WEBDAV_SERVER, username=USERNAME, password=PASS,protocol='http')
print webdav.ls("webdav")
webdav.delete("webdav/sample.txt")
webdav.upload("sample.local.txt","webdav/folder/sample3.txt")
webdav.mkdir("webdav/folder3")