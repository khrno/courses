import easywebdav

IP_WEBDAV_SERVER = "ubuntu"
USERNAME = "testuser1"
PASS = "q1w2e3"

#Without Authentication -- OK
# webdav = easywebdav.connect(IP_WEBDAV_SERVER, protocol='http')
# print webdav.ls("webdav")

#Basic Authentication -- OK
# webdav = easywebdav.connect(IP_WEBDAV_SERVER, username=USERNAME, password=PASS,protocol='http')
# print webdav.ls("webdav")
# webdav.upload("sample.local.txt","webdav/sample.txt")
# webdav.download("webdav/sample.txt", 'sample.local2.txt')
# webdav.mkdir("webdav/folder")
# webdav.upload("file2.txt","webdav/folder/sample2.txt")

#Basic Authentication + SSL -- OK
webdav = easywebdav.connect(IP_WEBDAV_SERVER, username=USERNAME, password=PASS,protocol='https', port=443, verify_ssl="cacert.pem")

print webdav.ls("webdav")