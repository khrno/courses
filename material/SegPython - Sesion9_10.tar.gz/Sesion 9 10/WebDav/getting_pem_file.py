import ssl
import os

cert = ssl.get_server_certificate(("10.6.40.11",443))

pem_path = os.path.expanduser('cacert.pem')
with open(pem_path, 'a+') as f:
	f.write(cert)