import urllib2
import ssl

context = ssl.create_default_context()
context.load_verify_locations(cafile = "cacert.pem")
print context.get_ca_certs()
r = urllib2.urlopen("https://ubuntu/", context=context)

print r.read()