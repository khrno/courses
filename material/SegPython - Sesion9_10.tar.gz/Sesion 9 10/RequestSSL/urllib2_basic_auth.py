import urllib2

IP_DESTINO = "172.17.1.110"
USER = "user1"
PASS = "q1w2e3"

####################################################
############## Basic Authentication ################
####################################################
REALM = "basicauth"
URL = "http://%s/basicauth" % IP_DESTINO

auth_handler = urllib2.HTTPBasicAuthHandler()
auth_handler.add_password(REALM, IP_DESTINO, USER, PASS)
opener = urllib2.build_opener(auth_handler)
urllib2.install_opener(opener)
r = urllib2.urlopen(URL)
headers = r.headers()

print headers