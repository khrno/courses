import urllib2

IP_DESTINO = "172.17.1.110"
USER = "linuxcenter"
PASS = "q1w2e3"

####################################################
############## Digest Authentication ###############
####################################################
REALM = "digestauth"
URL = "http://%s/digestauth" % IP_DESTINO

auth_handler = urllib2.HTTPDigestAuthHandler()
auth_handler.add_password(REALM, IP_DESTINO, USER, PASS)
opener = urllib2.build_opener(auth_handler)
urllib2.install_opener(opener)

r = urllib2.urlopen(URL)
print r.read()

