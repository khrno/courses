import scrapy

class HideMyAssSpider(scrapy.Spider):
    name = "hidemyass"

    allowed_domains = ["hidemyass.com"]
    start_urls = [
        "http://proxylist.hidemyass.com/"
    ]

    def parse(self, response):
        filename = response.url.split("/")[-2] + ".html"
        with open(filename, "wb") as f:
            f.write(response.body)
            