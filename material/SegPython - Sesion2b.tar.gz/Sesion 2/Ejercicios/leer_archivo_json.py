import json

filename = "series.json"

jsonFile = open(filename,"rb")
jsonData = jsonFile.read()
jsonFile.close()

data = json.loads(jsonData)

for r in data["results"]["bindings"]:
	print r["serie"]["value"]