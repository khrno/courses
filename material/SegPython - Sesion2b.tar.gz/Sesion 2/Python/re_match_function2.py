#!/usr/bin/python
import re

line = "Cats are smarter than dogs"

mo = re.match( r'(.*) are (.*?) .*', 
	line, re.M|re.I)

if mo:
   print "mo.group() : ", mo.group()
   print "mo.group(1) : ", mo.group(1)
   print "mo.group(2) : ", mo.group(2)
else:
   print "No match!!"