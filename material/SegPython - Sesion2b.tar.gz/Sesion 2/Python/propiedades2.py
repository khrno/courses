class Ojo(): 
    forma = "" 
    color = "" 
    tamanio = ""
 
class Objeto(): 
    color = "" 
    tamanio = "" 
    aspecto = "" 
    antenas = Antena()
    ojos = Ojo()
    pelos = Pelo()