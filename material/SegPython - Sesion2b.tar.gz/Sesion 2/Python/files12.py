#!/usr/bin/python
import os

# Eliminamos el archivo codehero.txt
os.remove("codehero.txt")