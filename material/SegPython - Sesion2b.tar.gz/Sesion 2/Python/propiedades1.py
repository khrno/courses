class Antena(): 
    color = "" 
    longitud = "" 
 
class Pelo(): 
    color = "" 
    textura = "" 
 
class Ojo(): 
    forma = "" 
    color = "" 
    tamanio = ""