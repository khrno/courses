class Madre():
    def __init__(self):
        self.x = 10;
        print("Constructor de la clase madre")

    def metodo(self):
        print("Ejecutando metodo de clase madre")