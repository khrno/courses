#!/usr/bin/python
# Abrimos el archivo codehero.txt
fo = open("codehero.txt", "wb")
fo.write("""Codehero.co es una gran pagina para 
	aprender a programar Python.\n""");
# Cerramos el archivo codehero.txt
fo.close()