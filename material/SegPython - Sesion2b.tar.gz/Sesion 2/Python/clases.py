class Objeto:
    pass
 
class Antena:
    pass
 
class Pelo:
    pass
 
class Ojo:
    pass