#!/usr/bin/python

objecto_archivo.close();