#!/usr/bin/python
os.rename(current_file_name, new_file_name)