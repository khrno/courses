et = Objeto() 
print et.color 
print et.tamanio 
print et.aspecto 
et.color = "rosa" 
print et.color