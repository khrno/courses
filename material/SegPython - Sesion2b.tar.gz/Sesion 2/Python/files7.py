#!/usr/bin/python
objecto_archivo.read([count]);