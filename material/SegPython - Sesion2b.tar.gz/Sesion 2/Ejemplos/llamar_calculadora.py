import calculadora

a = int(raw_input("ingrese primer valor: "))
b = int(raw_input("ingrese segundo valor: "))

calculadora.sumar(a,b)
calculadora.restar(a,b)
calculadora.multiplicar(a,b)
calculadora.dividir(a,b)