fo = open("numeros.txt","wb")

for i in range(1,1000001):
	fo.write("%d\n" % i)

fo.close()