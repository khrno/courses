import nltk

filename = "data/society.lyrics.txt"

with open(filename,"r") as filedata:
	text = filedata.read()

tokens = nltk.word_tokenize(text)
tokenstagged = nltk.pos_tag(tokens)

print "Nouns"
for token,tag in tokenstagged:
	if tag.startswith("N"):
		print token,tag

print "Verbs"
for token,tag in tokenstagged:
	if tag.startswith("V"):
		print token,tag