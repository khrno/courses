from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler

class PUTHandler(BaseHTTPRequestHandler):
	def do_PUT(self):
		print "----- SOMETHING WAS PUT!! ------"
		print self.headers
		length = int(self.headers['Content-Length'])
		content = self.rfile.read(length)
		self.send_response(200)
		print content

if __name__ == "__main__":
	port = 8086
	print("Starting a server on port %i" % port)
	server_address = ('172.17.1.64', port)
	httpd = HTTPServer(server_address, PUTHandler)
	httpd.serve_forever()