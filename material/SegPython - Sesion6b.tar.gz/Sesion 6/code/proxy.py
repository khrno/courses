# a truly minimal HTTP proxy


from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer 
import urllib

PORT = 8123

class Proxy(BaseHTTPRequestHandler):
    def do_GET(self):
        self.copyfile(urllib.urlopen(self.path), self.wfile)

if __name__ == "__main__":
	httpd = HTTPServer(('', PORT), Proxy)
	print "serving at port", PORT
	httpd.serve_forever()