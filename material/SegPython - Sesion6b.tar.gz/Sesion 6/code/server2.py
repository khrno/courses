from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer

class HolaMundoServer(BaseHTTPRequestHandler):
	def do_GET(self):
		parameters = self.path.split("/")[1:]
		message = "Hola %s !" % parameters[0]
		self.send_response(200)
		self.end_headers()
		self.wfile.write(message)

if __name__ == '__main__':
	server = HTTPServer(('localhost',8082), HolaMundoServer)
	print 'Starting server, use <Ctrl-C> to stop'
	server.serve_forever()