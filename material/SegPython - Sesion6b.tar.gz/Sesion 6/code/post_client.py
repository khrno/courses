import requests

#Server 4

payload = {'some': 'data'}
r = requests.post("http://localhost:8084/upload", data = payload)


print r.status_code
print r.text


