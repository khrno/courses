




from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler

import cgi
import os

class UploadFileHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={'REQUEST_METHOD':'POST',
            'CONTENT_TYPE':self.headers['Content-Type'],
        })
        filename = form['file'].filename
        data = form['file'].file.read()
        open("%s" %filename, "wb").write(data)

        self.respond("uploaded %s, thanks" % filename)

    def do_GET(self):
        parameters = self.path.split("/")[1:]
        if parameters[0] == 'download':
            filename = parameters[1]
            if os.path.exists(filename):
                with open(filename) as fh:
                    self.respond(fh.read().encode())
            else:
                self.send_error(404, 'File not found')
        elif parameters[0] == 'upload' :
            response = """
                <html><body>
                <form enctype="multipart/form-data" method="post">
                <p>File: <input type="file" name="file"></p>
                <p><input type="submit" value="Upload"></p>
                </form>
                </body></html>
            """
            self.respond(response)
        elif parameters[0] == 'list':
            files = os.listdir(".")
            content = ""
            for f in files:
                if f.endswith("txt"):
                    content += "<a href='download/"+f+"'>"+f+"</a><br>"
            self.respond(content)
        else:
            self.respond("No encontrado", 401)

    def do_PUT(self):
        self.respond("Metodo no implementado")

    def respond(self, response, status=200):
        self.send_response(status)
        self.send_header("Content-type", "text/html")
        self.send_header("Content-length", len(response))
        self.end_headers()
        self.wfile.write(response)


if __name__ == '__main__':
    server = HTTPServer(('localhost', 8087), UploadFileHandler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()