import requests




r = requests.options("http://www.integraseos.cl")
print r.headers