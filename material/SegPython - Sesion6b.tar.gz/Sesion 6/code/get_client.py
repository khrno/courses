import requests
import urllib

#Server1
r = requests.get("http://localhost:8081")

#Server2
r = requests.get("http://localhost:8082/Soy Tu Padre")

#Server3
r = requests.get("http://localhost:8083/",headers={"user":"Pablo","pass":"MiPASS"})
print urllib.unquote(r.text)

print r.status_code