from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer

class BasicWebServer(BaseHTTPRequestHandler):
	def do_GET(self):
		
		message = "Hola Mundo!"
		self.send_response(200)
		self.end_headers()
		self.wfile.write(message)

if __name__ == '__main__':
	server = HTTPServer(('localhost',8081), BasicWebServer)
	print 'Starting server, use <Ctrl-C> to stop'
	server.serve_forever()