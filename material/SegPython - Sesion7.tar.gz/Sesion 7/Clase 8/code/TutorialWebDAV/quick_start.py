import easywebdav

webdav = easywebdav.connect('192.168.0.22', username='pablo', password='q1w2e3', protocol='http', verify_ssl=False)
print webdav.ls()