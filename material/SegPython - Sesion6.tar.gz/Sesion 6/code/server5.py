from BaseHTTPServer import HTTPServer, BaseHTTPRequestHandler

import cgi
import os

class UploadFileHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        form = cgi.FieldStorage(
            fp=self.rfile,
            headers=self.headers,
            environ={'REQUEST_METHOD':'POST',
            'CONTENT_TYPE':self.headers['Content-Type'],
        })
        filename = form['file'].filename
        data = form['file'].file.read()
        open("%s" %filename, "wb").write(data)

        self.respond("uploaded %s, thanks" % filename)

    def do_GET(self):
        if self.path == '/download':
            if os.path.exists("file.txt"):
                with open("file.txt") as fh:
                    self.respond(fh.read().encode())
            else:
                self.send_error(404, 'File not found')
        else:
            response = """
                <html><body>
                <form enctype="multipart/form-data" method="post">
                <p>File: <input type="file" name="file"></p>
                <p><input type="submit" value="Upload"></p>
                </form>
                </body></html>
            """
            self.respond(response)

    def respond(self, response, status=200):
        self.send_response(status)
        self.send_header("Content-type", "text/html")
        self.send_header("Content-length", len(response))
        self.end_headers()
        self.wfile.write(response)


if __name__ == '__main__':
    server = HTTPServer(('', 8085), UploadFileHandler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()