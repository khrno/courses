from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
import os

class StoreHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path == '/download':
            if os.path.exists("file.txt"):
                with open("file.txt") as fh:
                    self.send_response(200)
                    self.send_header('Content-type', 'text/plain')
                    self.end_headers()
                    self.wfile.write(fh.read().encode())
            else:
                self.send_error(404, 'File not found')

    def do_POST(self):
        if self.path == '/upload':
            length = self.headers['content-length']
            data = self.rfile.read(int(length))

            with open("file.txt", 'w') as fh:
                fh.write(data.decode())

            self.send_response(200)

if __name__ == '__main__':
    server = HTTPServer(('', 8084), StoreHandler)
    print 'Starting server, use <Ctrl-C> to stop'
    server.serve_forever()