import requests
requests.get(url, params=None, **kwargs)
requests.post(url, data=None, json=None, 
	**kwargs)
requests.put(url, data=None, **kwargs)