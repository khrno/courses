from BaseHTTPServer import BaseHTTPRequestHandler,HTTPServer

class CredentialsNeedWebServer(BaseHTTPRequestHandler):
	def do_GET(self):
		usuario = self.headers.getheader('user',None)
		password = self.headers.getheader('pass',None)
		if usuario == "Pablo" and password=="MiPASS":
			message = "Hola Pablo con Password !"
			self.send_response(200)
			self.end_headers()
			self.wfile.write(message)
		else:
			self.send_response(401)
			self.end_headers()
			self.wfile.write("Acceso invalido")


if __name__ == '__main__':
	server = HTTPServer(('localhost',8083), CredentialsNeedWebServer)
	print 'Starting server, use <Ctrl-C> to stop'
	server.serve_forever()