
INSERT INTO categoria(nombre) VALUES ('historica');
INSERT INTO serie(nombre, id_categoria) VALUES ('Game Of Thrones', 1);

INSERT INTO temporada(numero, id_serie) VALUES(1, 1);
INSERT INTO temporada(numero, id_serie) VALUES(2, 1);
INSERT INTO temporada(numero, id_serie) VALUES(3, 1);
INSERT INTO temporada(numero, id_serie) VALUES(4, 1);
INSERT INTO temporada(numero, id_serie) VALUES(5, 1);

INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(1, 'Winter Is Coming', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(2, 'The Kingsroad', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(3, 'Lord Snow', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(4, 'Cripples, Bastards, and Broken Things', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(5, 'c5', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(6, 'c6', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(7, 'c7', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(8, 'c8', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(9, 'c9', '2011-04-17', 1);
INSERT INTO episodio(numero, nombre, fecha_lanzamiento, id_temporada) VALUES(10, 'c10', '2011-04-17', 1);